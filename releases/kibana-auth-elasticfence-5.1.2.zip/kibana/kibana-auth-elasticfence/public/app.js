require('ui/routes').disable();
